"""Optional real EDF integration test; safely skipped without a local dataset."""
import importlib.util
import os
from pathlib import Path
import unittest

from neuroguard_core import discover_recordings, iter_record_windows, load_edf


class RealEDFIntegrationTest(unittest.TestCase):
    @unittest.skipUnless(importlib.util.find_spec("mne"), "MNE unavailable")
    def test_real_edf_if_dataset_present(self):
        root = Path(os.environ.get("NEUROGUARD_DATA", "/content/neuroguard_data"))
        if not root.exists() or not any(root.rglob("*.edf")):
            self.skipTest("No real EDF locally")
        audit = discover_recordings(root)
        self.assertGreater(audit["edf_files_found"], 0)
        if not audit["accepted_recordings"]:
            self.skipTest("No EDF with verified summaries and required channels")
        record = audit["accepted_recordings"][0]
        raw = load_edf(record["file"])
        try:
            self.assertGreater(raw.n_times, 0)
        finally:
            raw.close()
        first = next(iter_record_windows(record), None)
        if first is not None:
            features, label, information = first
            self.assertEqual(len(features), 160)
            self.assertIn(label, [0, 1])
            self.assertLess(information["start_seconds"], information["end_seconds"])

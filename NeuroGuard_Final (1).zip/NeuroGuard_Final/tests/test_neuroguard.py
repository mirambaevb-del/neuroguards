"""Offline tests. Synthetic EEG fixtures are ONLY for software validation."""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import joblib
import numpy as np
from fastapi.testclient import TestClient
from sklearn.ensemble import RandomForestClassifier

from api import app
from inference import NeuroGuardDetector, StreamingEEGSession, temporal_confirmation
from neuroguard_core import (CHANNELS, Config, discover_recordings, extract_features,
                             feature_names, label_window, normalize_channel, compare_filtering_methods,
                             parse_summary, preprocess_window, select_channels,
                             split_records, split_records_three_way, validate_intervals)
from prediction_research import candidate_preictal_label


def fake_eeg(seed: int, hz: float = 6.0):
    """Synthetic oscillation: test fixture, NOT a seizure recording."""
    rng = np.random.default_rng(seed)
    t = np.arange(1024) / 256
    return np.stack([1e-5 * np.sin(2 * np.pi * (hz + i / 2) * t) +
                     1e-6 * rng.normal(size=1024) for i in range(8)])


class CoreTests(unittest.TestCase):
    def test_summary_parser_zero_multiple_and_plus_name(self):
        summary = """File Name: chb01_01.edf
Number of Seizures in File: 0
File Name: chb02_16+.edf
Number of Seizures in File: 2
Seizure 1 Start Time: 130 seconds
Seizure 1 End Time: 212 seconds
Seizure 2 Start Time: 300 seconds
Seizure 2 End Time: 320 seconds
"""
        p = parse_summary(summary)
        self.assertEqual(p["chb01_01.edf"]["intervals"], [])
        self.assertEqual(p["chb02_16+.edf"]["intervals"], [(130.0, 212.0), (300.0, 320.0)])

    def test_summary_incomplete_raises(self):
        with self.assertRaises(ValueError):
            parse_summary("File Name: chb01_03.edf\nNumber of Seizures in File: 1\n")

    def test_missing_summary_is_not_implicitly_negative(self):
        with tempfile.TemporaryDirectory() as directory:
            Path(directory, "chb01_01.edf").touch()
            audit = discover_recordings(directory)
            self.assertEqual(audit["interictal_windows"], 0)
            self.assertEqual(audit["status"], "blocked_no_valid_recordings")
            self.assertEqual(len(audit["missing_or_invalid_annotations"]), 1)

    def test_boundary_windows_are_excluded(self):
        event = [(5, 12)]
        self.assertEqual(label_window(0, 4, event), 0)
        self.assertIsNone(label_window(4, 8, event))
        self.assertEqual(label_window(8, 12, event), 1)
        with self.assertRaises(ValueError):
            validate_intervals([(0, 200)], 100)

    def test_channels_and_missing_channels(self):
        ch = [s.lower().replace("-", " - ") for s in CHANNELS]
        self.assertEqual(len(select_channels(ch)), 8)
        self.assertEqual(normalize_channel(" fp1 - f7 "), "FP1F7")
        with self.assertRaises(ValueError):
            select_channels(["FP1-F7"])

    def test_feature_extraction_finite_order(self):
        x = preprocess_window(fake_eeg(23))
        feats = extract_features(x)
        self.assertEqual(feats.shape, (len(feature_names()),))
        self.assertTrue(np.all(np.isfinite(feats)))
        self.assertEqual(len(feats), 8 * 20)

    def test_filtering_boundary_difference_is_reported(self):
        x = np.concatenate([fake_eeg(1), fake_eeg(2), fake_eeg(3)], axis=1)
        comparison = compare_filtering_methods(x)
        self.assertGreaterEqual(comparison["rms_difference_volts"], 0)
        self.assertGreater(comparison["max_absolute_difference_volts"], 0)

    def test_nan_rejected(self):
        x = fake_eeg(3)
        x[0, 5] = np.nan
        with self.assertRaises(ValueError):
            preprocess_window(x)

    def test_patient_split_never_mixes(self):
        recs = [{"patient": p, "file": p} for p in ["chb01", "chb02", "chb03"]]
        train, test = split_records(recs)
        self.assertEqual({r["patient"] for r in train}, {"chb01", "chb02"})
        self.assertEqual({r["patient"] for r in test}, {"chb03"})
        with self.assertRaises(ValueError):
            split_records(recs[:2])
        training, validation, testing = split_records_three_way(recs)
        self.assertEqual([r["patient"] for r in training], ["chb01"])
        self.assertEqual([r["patient"] for r in validation], ["chb02"])
        self.assertEqual([r["patient"] for r in testing], ["chb03"])
        with self.assertRaises(ValueError):
            split_records_three_way(recs, {"train": ["chb01", "chb02"],
                                             "validation": ["chb02"], "test": ["chb03"]})

    def test_prediction_label_protocol_is_distinct(self):
        seizures = [(2000, 2050)]
        params = {"continuous_intervals": [(0, 4000)], "annotation_verified_through": 4000}
        self.assertEqual(candidate_preictal_label(300, 304, seizures, **params), 1)
        self.assertEqual(candidate_preictal_label(100, 104, seizures, **params), 0)
        self.assertIsNone(candidate_preictal_label(1700, 1704, seizures, **params))
        self.assertIsNone(candidate_preictal_label(2020, 2024, seizures, **params))
        self.assertIsNone(candidate_preictal_label(100, 104, seizures))
        self.assertIsNone(candidate_preictal_label(100, 104, seizures,
                           continuous_intervals=[(0, 400), (500, 4000)],
                           annotation_verified_through=4000))

    def test_no_data_not_reported_as_success(self):
        audit = discover_recordings("/path/that/does/not/exist/neuroguard")
        self.assertEqual(audit["status"], "blocked_missing_dataset")
        self.assertEqual(audit["edf_files_found"], 0)


class InferenceAndAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        base = Path(cls.temp.name)
        c = Config()
        x = np.stack([extract_features(preprocess_window(fake_eeg(k, 6 if k < 4 else 12)))
                      for k in range(8)])
        y = np.asarray([0] * 4 + [1] * 4)
        model = RandomForestClassifier(n_estimators=10, random_state=42)
        model.fit(x, y)
        joblib.dump(model, base / "seizure_detector.joblib")
        (base / "config.json").write_text(json.dumps(c.to_json()))
        (base / "features.json").write_text(json.dumps({"feature_names": feature_names(c)}))
        (base / "manifest.json").write_text(json.dumps({"version": "SYNTHETIC_SOFTWARE_TEST_ONLY"}))
        cls.base = base

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_model_load_and_infer(self):
        detector = NeuroGuardDetector(self.base)
        result = detector.predict_array(fake_eeg(123), list(CHANNELS), 256, unit="V")
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["windows"]), 1)
        self.assertEqual(result["windows"][0]["start_seconds"], 0)
        self.assertIsNone(result["windows"][0]["calibrated_probability"])

    def test_invalid_sampling_rate(self):
        with self.assertRaises(ValueError):
            NeuroGuardDetector(self.base).predict_array(fake_eeg(123), list(CHANNELS), 128, unit="V")

    def test_inference_requires_explicit_units(self):
        with self.assertRaises(ValueError):
            NeuroGuardDetector(self.base).predict_array(fake_eeg(123), list(CHANNELS), 256, unit="uV")

    def test_stream_retains_partial_window(self):
        detector = NeuroGuardDetector(self.base)
        stream = StreamingEEGSession(detector)
        x = fake_eeg(12)
        first = stream.push(x[:, :300], list(CHANNELS), 256, unit="V")
        self.assertEqual(len(first), 0)
        self.assertEqual(stream.buffer.shape[1], 300)
        second = stream.push(x[:, 300:], list(CHANNELS), 256, unit="V")
        self.assertEqual(len(second), 1)
        self.assertEqual(stream.buffer.shape[1], 0)
        self.assertEqual(stream.finalize()["unscored_remainder_samples"], 0)

    def test_temporal_confirmation_is_explicit(self):
        windows = [{"label": value} for value in ["ICTAL", "ICTAL", "INTERICTAL"]]
        confirmed = temporal_confirmation(windows)
        self.assertEqual([w["temporally_confirmed_ictal"] for w in confirmed], [False, True, False])

    def test_api_health_and_prediction(self):
        with patch.dict(os.environ, {"NEUROGUARD_MODEL_DIR": str(self.base)}):
            with TestClient(app) as client:
                self.assertEqual(client.get("/health").status_code, 200)
                self.assertTrue(client.get("/health").json()["model_available"])
                info = client.get("/model-info")
                self.assertEqual(info.status_code, 200)
                result = client.post("/predict", json={"channels": list(CHANNELS),
                                                         "samples": fake_eeg(4).tolist(), "sfreq": 256, "unit": "V"})
                self.assertEqual(result.status_code, 200, result.text)
                self.assertEqual(result.json()["task"], "SEIZURE_DETECTION_NOT_PREDICTION")
                too_large = client.post("/predict", content=b"0" * (4 * 1024 * 1024 + 1))
                self.assertEqual(too_large.status_code, 413)

    def test_untrained_server_returns_503(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"NEUROGUARD_MODEL_DIR": directory}):
                with TestClient(app) as client:
                    result = client.get("/model-info")
                    self.assertEqual(result.status_code, 503)
                    self.assertEqual(len(client.get("/health").json()["missing_model_files"]), 4)


if __name__ == "__main__":
    unittest.main()

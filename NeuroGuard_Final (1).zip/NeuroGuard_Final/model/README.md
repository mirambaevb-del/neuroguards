No trained model is included because the actual CHB-MIT EDF recordings were not available in the build environment.

After successful **real EEG** training, the script will create:

- `seizure_detector.joblib`
- `config.json`
- `features.json`
- `manifest.json`

Never substitute a model trained on synthetic tests for a real EEG model.
